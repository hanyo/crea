# reference manual test
File.exist?(File.join(File.dirname(__FILE__), '../reference/rubyrefm-remix-1.9.3.chm')) or raise "reference manual is not correctly installed."
