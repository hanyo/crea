# coding: utf-8
require("mechanize")
require("inifile")
require("time")

ini = IniFile.load("crea.ini")

#p ini

username = ini['account']['name']
password = ini['account']['pass']
count = ini['count']['value']
clock = ini['time']['value']
messe =ini['messe']['value']

#puts messe
#exit

#puts username
#puts password
#puts count
#puts clock

puts
puts "◆ " + count.to_s + "回処理を実行します。" 
puts

if clock != "now" 
  #time = Time.parse ARGV.join(" ")
  #time = Time.parse clock.join(" ")
  time = Time.parse clock
  if time < Time.now
     puts "起動時間が過去に設定されています。"
     puts
     puts "処理を終了します。"
     puts
     exit
  end
  secs = time - Time.now
  puts "#{time} まで #{secs} 秒間実行を待ちます。 "
  sleep secs
end

puts
puts "◆ 実行を開始します。"
puts

url1 = "http://crea-tv.jp/User/ViComm/woman/(S(IMPACT-VMSVR230001kg0e7rppm3c13o00x2))/LoginUser.aspx?loginid=" + username.to_s + "&password=" + password.to_s + "&timeout=1&nopc=1&urlsex=3&call=LoginUser.aspx"


agent = Mechanize.new

puts
puts "◆ サイトにログインしました。"
puts
for i in 1..count.to_i 
  #page = agent.get("http://crea-tv.jp/User/ViComm/woman/(S(IMPACT-VMSVR230001kg0e7rppm3c13o00x2))/LoginUser.aspx?loginid=16393179&password=1216&timeout=1&nopc=1&urlsex=3&call=LoginUser.aspx") # ログインフォームのある URI
  page = agent.get(url1) # ログインフォームのある URI
  #agent.page.encoding = 'Shift_JIS' 


  puts "◆ " + i.to_s + "回目の処理を実行します。"
  puts
  form = page.form("frmMain") # ログイン情報 (ユーザ名とかパスワード) を入力させるフォームの名前
  #form.field_with(:name => "txtLoginId").value = "16393179" # ユーザ名
  #form.field_with(:name => "txtPassword").value = "1216" # パスワード (簡単のため平文で)
  next_page =  form.click_button(form.button_with(:value => 'ﾛｸﾞｲﾝ'))
  #form.submit()

  sleep 2 
  next_page2 =  next_page.links[22].click
  sleep 1 
  #p next_page2.links

  # 1ページ目の10人分の氏名取得
  puts "  ==> ログイン中のユーザを10人取得しています。"
  puts
  name = []
  i = 0
  for num in [4,6,8,10,12,14,16,18,20,22]
    name[i] =  next_page2.links[num].text
    puts  "    " + name[i]
    i= i + 1
  end
  puts

  # bodyのエンコードをUTF-8に変換し改行コードをCRLF=>LFに
  data1 = ""
  data1 = next_page2.body.toutf8.gsub(/\r\n/,"\n")

  sleep 2
  # 最初のメール授受０の人物取得
  puts "  ==> 最初のメール授受0のユーザを取得しています。"
  g = ""
  i = 0
  data1.split("\n").each do |line|
    if line =~ /受/ then
      if line =~ /受:0&nbsp;送:0/ then
         g = "GET"
         #puts i
         #puts line
         break
      end
         i = i + 1
    end
  end
  
  puts
  sleep 5
  if g == "GET" 
    puts "  ==> 『" + name[i] + "』さんにメッセージを送信します！"
    puts

    link =   next_page2.links_with(:text => "ﾒｰﾙを送る")[i]

    next_page3 = link.click

    form = next_page3.form("frmMain") # ログイン情報 (ユーザ名とかパスワード) を入力させるフォームの名前
    #form.field_with(:name => "txtDoc$TextBox1").value = "はじめまして♪
#よかったら絡みましょ(^-^)" 
    form.field_with(:name => "txtDoc$TextBox1").value = messe
    next_page4 =  form.click_button(form.button_with(:value => '送信する'))

    sleep 2
 
    puts "  ==> メッセージ送信を完了しました。"
    puts
    #page =  next_page4.link_with(:text => "ﾏｲﾍﾟｰｼﾞへ戻る").click
  else
    puts "  ==> メール授受0のユーザが見つかりませんでした。"
    puts
    #page =  next_page2.link_with(:text => "\r\n\r\nﾏｲﾍﾟｰｼﾞへ戻る\r\n").click
  end

  sleep 7

end #for
puts "◆ 処理を終了します。"
